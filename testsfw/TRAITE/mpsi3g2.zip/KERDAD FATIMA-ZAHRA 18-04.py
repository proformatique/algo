def rechercher(nom_du_fichier, mot_a_fichier)-> list :
    '''
        * retourne un tableau contenant les indices des lignes 
           contenant le mot_a_fichier
        - données : nom_du_fichier, mot_a_fichier
        _ sortie : l un tableau contnant les indices des lignes
    '''
    resultat = []
    with open('nom_du_fichier','r', encoding= 'utf-8') as file :
        lignes = file.readlines()
        for i in range(len(lignes)):
            if mot_a_fichier in lignes :
                resultat += [i + 1]
    return resultat

def inserer(tab, element)-> list :
    '''
    * retourne un tableau trié dont l'element 
       - données : un tableau trié , un element 
       - sortie : un tableau contenant l'element trié
    >>> a = [1, 5, 9, 11]
    >>> inserer(a,2)
    [1, 2, 5, 9, 11]
    >>> inserer([],5)
    [5]
    '''
    resultat = []
    taille = len(tab)
    id = taille // 2
    if taille == 0 :
        resultat = [element]
    else :
         if tab[id] <= element  :
            resultat = tab[:id + 1] + inserer(tab[id +1 : ], element)
         else :
            resultat = inserer(tab[:id ], element) + tab[id :]
    return resultat