def recherche(nom_du_fichier, mot_a_chercher) -> list:
    r''' Ce script permet de rechercher les lignes qui comportent un mot donné.
    >>> recherche(r'C:\Users\Lydex\Desktop\Mahdi.txt', 'Mahdi')
    [1, 4, 7, 9]
    '''
    resultat = []
    l = 0
    with open(nom_du_fichier, 'r', encoding= 'utf_8') as f:
        texte = f.readlines()
        for ligne in texte:
            l += 1
            if mot_a_chercher in ligne:
                resultat += [l]
    return resultat
    
if __name__ == '__main__':
    import doctest as dt
    dt.testmod(verbose=True)

def inserer(tab, element) -> list:
    ''' Ce script permet de insérer un élément dans un tableau par dichotomie récursive.
    >>> inserer([1, 2, 3, 4], 2)
    [1, 2, 2, 3, 4]
    >>> inserer([], 2)
    [2]
    >>> inserer([1, 2, 9, 11], 8)
    [1, 2, 8, 9, 11]
    '''
    if len(tab) == 0:
        return [element]
    elif len(tab) == 1:
        if element > tab[0]:
            return tab + [element]
        else:
            return [element] + tab
    else:
        n = len(tab)//2
        if element < tab[n]:
            return inserer(tab[:n], element) + tab[n:]
        else:
            return tab[:n] + inserer(tab[n:], element)

if __name__ == '__main__':
    import doctest as dt
    dt.testmod(verbose=True)