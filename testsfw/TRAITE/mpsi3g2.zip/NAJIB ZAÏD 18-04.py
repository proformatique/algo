"""
Exercice
"""
def recherche(nom_fichier, mot_a_chercher) -> list:
    """
    >>> recherche('E:/mpsi33/tp12/text.txt', 'top')
    [2]
    """
    res = []
    with open(nom_fichier) as file:
        for i, l in enumerate(file):
            if mot_a_chercher in l:
                res.append(i + 1)
    return res
def inserer(tab, element) -> list:
    """
    >>> inserer([1, 2, 3, 5], 2.5)
    [1, 2, 2.5, 3, 5]
    """
    if not tab:
        return [element]
    elif tab[len(tab)//2] < element:
        return tab[:len(tab)//2 + 1] + inserer(tab[len(tab)//2 + 1:], element)
    else:
        return inserer(tab[:len(tab)//2], element) + tab[len(tab)//2:]
if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
