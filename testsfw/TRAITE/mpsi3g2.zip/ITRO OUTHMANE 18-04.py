"""
ITRO OUTHMANE
EXERCICES
"""

def recherche(nom_du_fichier, mot_a_chercher):
    '''
    >>> recherche('texte.txt', 'def')
    [1,2,4,6]
    '''
    lignes = []
    with open(nom_du_fichier, mode="r", encoding='utf-8') as file:
        for i, line in enumerate(file):
            if mot_a_chercher in line:
                lignes.append(i+1)
    return lignes

def inserer(tab, element):
    '''
    >>> inserer([1,2,3,5,6], 4):
    [1,2,3,4,5,6]
        '''
    if tab == []:
        return [element]
    if element > tab[len(tab)//2]:
        return tab[:(len(tab)//2+1)] + inserer(tab[(len(tab)//2+1):], element)
    return inserer(tab[:(len(tab)//2)], element) + tab[(len(tab)//2):]

if __name__ == '__main__':
    import doctest as dt
    dt.testmod(verbose=True)