# -*- coding: utf-8 -*-
"""
Created on Tue Apr 17 11:25:51 2018

@author: Lydex
"""
def recherche(nom_du_ficher, mot_a_chercher) -> list:
    
    """ chercher un element dans un ficher """
    L = []
    fichier = open("nom_du_ficher.txt", "r")
    lignes = fichier.readlines()
    fichier.close()
    for i in lignes:
        if mot_a_chercher in i:
            L += [lignes.index(i) + 1]
    return L

def inserer(tab, element) -> list:
    
    """
    Donnees:
        Entrée : tab(list), element(float)
        Sortie : (list)
    >>> inserer([1, 3, 8, 15, 35], 17)
    [1, 3, 8, 15, 17, 35]
    
    >>> inserer([], 10)
    [10]
    """
    l = len(tab)
    if l == 0:
        return [element]
    else :
        if tab[l//2] < element:
            return tab[:l//2 + 1] + inserer(tab[l//2 +1 :], element)
        else:
            return inserer(tab[:n//2], element) + tab[l//2:]

if __name__ == '__main__':        
    import doctest as dt
    dt.testmod(verbose=True)
        
    

