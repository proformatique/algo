def rechercher(nom_du_fichier, mot_a_rechercher):
    "retourne la liste des indices des lignes qui comportent le mot à rechercher"
    with open(nom-du-fichier, 'r', encoding = 'utf-8') as f:
        t = []
        c = 0
        for lignes in f.readline:
            c += 1
            if mot_a_rechercher in lignes:
                t += [c]
        return t   
        
def inserer(tab, element):
    "on chercher l'indice convenable de l'élement puis on l'insert dans le tableau"
    ">>>insert([1, 2, 6], 5)) = [1, 2, 5,6]<<<" 
    if tab == []:
        return [element]
    else:
        milieu = tab[len(tab) // 2]
        if  element < tab[milieu]:
            liste = tab[:milieu + 1] + inverser(tab[:milieu + 1], element)
        else :
            liste = inserer(tab[:milieu+1], element) + tab[milieu:]
    return liste  
    
if '__name__'=='__main__':
    import doctest as dt
    dt.testmode(verbose=True)
              
            
                  