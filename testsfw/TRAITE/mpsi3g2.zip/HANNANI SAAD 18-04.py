def recherche(nom_du_fichier,mot_a_chercher):
    "retourner un tableau qui contient les lignes contenant un element "
    ">>>recherche('file.txt()','mot')"
    with open(nom_du_fichier,mode='r',encoding='utf_8') as fc :
        texte = fc.read()
    liste=[]
    compteur=0
    for lignes in texte.readline():
        compteur += 1
        if mot_a_chercher in lignes:
            liste += [compteur]
    return liste            
    
    
def inserer(tab,element):
    "on cherche l'emplacement d'un element puis on l'insere dans le tableau"
    ">>>inserer([1,2,4,5],3)"
    ">>>[1,2,3,4,5]"
    taille=len(tab)
    liste=[]
    if taille==0:
        liste = [element]
    else:
        milieu = taille//2
        if tab[milieu] < element:
            liste =tab[:milieu+1] + inserer(tab[milieu+1:],element)
        elif tab[milieu] >= element:
            liste = inserer(tab[:milieu],element) + tab[milieu:]
    return liste        

if '__name__'=='__main__':
    import doctest as dt
    dt.testmod(verbose=True)
            
            
                
         
        