def rechercher(nom_du_fichier,mot_a_chercher)->list:
    "retourne les indices des lignes contenant le mot qu'on cherche sous forme dune liste"
    ">>>recherche('file.txt()','mot')"
    ">>> [1,22,45]"
    file=open(nom_du_fichier,'r',encoding='utf-8')
    liste=[]
    compteur=0
    for ligne in file.readline():
        compteur+=1
        if mot_a_chercher in ligne:
            liste+=[compteur]
    return liste
##
def inserer(tab,element)->list:
    "retourne un tableau trié après avoir inseré l'élément"
    ">>> inserer([1,3,4,5,6,7,8],2)"
    ">>> [1,2,3,4,5,6,7,8]"
    taille=len(tab)
    indmilieu=taille//2
    if tab==[]:#cas de base
        liste=[element]
    elif element>tab[indmilieu]:#cas récursif
        liste=tab[:indmilieu+1]+inserer(tab[indmilieu+1:],element)
    else:
        liste=inserer(tab[:indmilieu],element)+tab[indmilieu:]
    return liste

if'__name__' == '__main__':
    import doctest as dt
    dt.testmod(verbose=True)
    