def recherche(nom_du_fichier, mot_a_chercher) -> list:
    '''retourne une liste des indices des lignes qui comporte le mot à chercher.
    Donnees:
           Entrée  : nom_du_fichier(str) ,mot_a_chercher(str)
           sortie  : L(list)
    ''' 
    L = []
    with open(nom_du_fichier, 'r', encoding = 'utf-8') as fs:
        texte = fs.read()
    lignes = texte.readlines()
    n = 1
    for i in lignes:
        if mot_a_chercher in i:
            L += [n]
        n += 1
    return L

def inserer(tab, element) -> list:
    """
    Retourne un tableau trié avec l'élément ajouté
    
    Donnees:
            Entrée : tab(list), element(float)
            Sortie : (liste)
            
    >>> inserer([1, 3, 8, 11, 13, 17, 20], 10)
    [1, 3, 8, 10, 11, 13, 17, 20]
    
    >>> inserer([], 1)
    [1]
    """
    n = len(tab)
    R = []
    if n == 0:
        R = [element]
    else:
        if tab[n//2] < element:
            R = tab[:n//2 + 1] + inserer(tab[n//2 + 1 :], element)
        else:
            R = inserer(tab[:n//2], element) + tab[n//2:]
    return R
            
if __name__ == '__main__':
    import doctest as dt
    dt.testmod(verbose = True)